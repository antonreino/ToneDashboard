"""Bounded task evidence: saved outcomes are not live service health."""
from datetime import datetime, timezone
import json
import re

from .storage import terms

# These describe maintenance generally; they cannot identify a particular task.
_GENERIC = frozenset('tarea tareas programada programadas mantenimiento revision revisiones revisar ejecutar ejecucion diario diaria semanal lunes mantener actualizar actualizaciones registro registros logs log ultimos ultimo'.split())
_MAX_CONTEXT = 10000


def _task_terms(text):
    return set(terms(str(text), None)) - _GENERIC


def _bounded(value, length=300, depth=0):
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value if len(value) <= length else value[:length] + ' […]'
    if depth >= 2:
        return None
    if isinstance(value, dict):
        return {str(k)[:60]: _bounded(v, length, depth + 1) for k, v in list(value.items())[:6]}
    if isinstance(value, list):
        return [_bounded(v, length, depth + 1) for v in value[:4]]
    return None


def _recent_logs(logs, dated_limit=1):
    """Order dated evidence in UTC; never silently discard undated evidence."""
    if not isinstance(logs, list):
        return [], False
    dated, unknown = [], []
    for log in logs[:100]:
        if not isinstance(log, dict):
            continue
        try:
            at = datetime.fromisoformat(str(log.get('at', '')).replace('Z', '+00:00'))
            if at.tzinfo is None:
                raise ValueError('Undated timezone')
            dated.append((at.astimezone(timezone.utc), log))
        except (ValueError, TypeError, OverflowError):
            unknown.append(log)
    dated.sort(key=lambda pair: pair[0], reverse=True)
    selected = [pair[1] for pair in dated[:dated_limit]]
    if unknown:
        selected.append(unknown[0])
    return selected, bool(unknown) or len(logs) > 100


def _entry(item, compare_dates=False):
    result = {k: _bounded(item.get(k)) for k in ('id', 'name', 'enabled', 'schedule', 'status', 'last_run', 'description', 'outcome', 'follow_up', 'execution', 'run_blocked_reason')}
    logs, uncertain = _recent_logs(item.get('logs'),3 if compare_dates else 1)
    result['logs'] = [{k: _bounded(log.get(k), 1800 if k == 'message' else 200) for k in ('at', 'status', 'message')} for log in logs]
    dated_seen=0
    for log in result['logs']:
        try:
            parsed=datetime.fromisoformat(str(log.get('at','')).replace('Z','+00:00'))
            if parsed.tzinfo is None:raise ValueError('Unknown timezone')
            log['time_basis']='latest_among_dated_logs_only' if dated_seen==0 else 'earlier_dated_log_in_window'
            log['at_utc']=parsed.astimezone(timezone.utc).isoformat()
            dated_seen+=1
        except (ValueError,TypeError,OverflowError):
            log['time_basis']='unordered_timezone_or_date_unknown'
    result['overall_latest_log_known']=bool(logs) and not uncertain
    raw=item.get('logs',[])
    result['log_window']={'scope':'provided_catalogue_records_only','dated_limit':3 if compare_dates else 1,'returned':len(logs),'provided':len(raw) if isinstance(raw,list) else 0}
    if uncertain:
        result['log_order_uncertain'] = True
    return result


def task_context(provider, query=''):
    """Choose named tasks, serialize whole records and disclose any size omissions."""
    if provider is None:
        return 'Catálogo no conectado; no inventes horarios.'
    try:
        data = provider()
        raw = data.get('tasks', [])
        if not isinstance(raw, list):
            raise ValueError('Invalid task catalogue')
        tasks = [item for item in raw if isinstance(item, dict)][:20]
        wanted = _task_terms(query)
        named = [item for item in tasks if wanted & _task_terms(str(item.get('id', '')) + ' ' + str(item.get('name', '')))]
        selected = named or tasks
        result = {'consulted_at': datetime.now(timezone.utc).isoformat(),
                  'evidence_kind': 'stored_results_not_live_service_health',
                  'matched_tasks': len(selected), 'omitted_tasks': max(0, len(raw) - len(tasks)) if not named else 0,
                  'tasks': [], 'warnings': _bounded(data.get('warnings', []), 200)}
        for item in selected:
            compare_dates=bool(re.search(r'orden|cronol|compara|fechados|zona|utc',query.casefold()))
            entry = _entry(item,compare_dates)
            result['tasks'].append(entry)
            if len(json.dumps(result, ensure_ascii=False)) > _MAX_CONTEXT:
                result['tasks'].pop()
                result['omitted_tasks'] += 1
        return json.dumps(result, ensure_ascii=False)
    except Exception:
        return 'No se pudo consultar el catálogo ahora; no equivale a tareas sanas ni fallidas.'

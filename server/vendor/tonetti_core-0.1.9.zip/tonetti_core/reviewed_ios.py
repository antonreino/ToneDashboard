"""One reviewed iOS deployment, not a shell or general agent tool."""
import hashlib
import json
from pathlib import Path
import plistlib
import subprocess

ARTIFACT = 'mario-tennis-copycommands-20261027'
BUNDLE = 'ovh.tonecas.nxnative.mariotennis'

def validate_proposal(proposal):
    if not isinstance(proposal,dict) or set(proposal)!={'action','artifact'} or proposal!={'action':'install_reviewed_ios','artifact':ARTIFACT}:
        raise ValueError('Only the reviewed Mario Tennis installation is allowed')

def tree_digest(app):
    app=Path(app).resolve();digest=hashlib.sha256()
    for p in sorted(app.rglob('*')):
        if not p.resolve().is_relative_to(app):raise ValueError('External app symlink')
        if p.is_file():
            digest.update(p.relative_to(app).as_posix().encode()+b'\0')
            with p.open('rb') as f:
                for chunk in iter(lambda:f.read(1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()

def execute(base,proposal,*,authorized=False,runner=subprocess.run):
    validate_proposal(proposal)
    if not authorized:raise ValueError('Explicit human authorization required')
    base=Path(base).resolve()
    manifest=json.loads((base/'nxnative-data/audit/comparison/reviewed-ios-deployment.json').read_text())
    app=base/'nxnative-data/ios-copy-fixed-20261027/DmIOS.app'
    if manifest.get('artifact')!=ARTIFACT or manifest.get('bundle')!=BUNDLE or not manifest.get('device'):
        raise ValueError('Invalid reviewed manifest')
    with (app/'Info.plist').open('rb') as f:
        if plistlib.load(f).get('CFBundleIdentifier')!=BUNDLE:raise ValueError('Bundle mismatch')
    if tree_digest(app)!=manifest.get('tree_sha256'):raise ValueError('Reviewed app changed')
    runner(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],check=True,timeout=60)
    output=base/'nxnative-data/audit/comparison/tonetti-ios-install.json'
    if output.exists():raise ValueError('Installation already attempted; inspect result before repeating')
    # Mark dispatch before handing over. Do not repeat uncertain installations.
    output.write_text(json.dumps({'state':'dispatching','artifact':ARTIFACT}))
    raw=output.with_name('tonetti-ios-install-device.json')
    try:
        result=runner(['/usr/bin/xcrun','devicectl','device','install','app','--device',manifest['device'],str(app),'--json-output',str(raw)],check=True,timeout=300,capture_output=True,text=True)
        data=json.loads(raw.read_text())
        apps=data.get('result',{}).get('installedApplications',[])
        if not any(a.get('bundleID')==BUNDLE for a in apps):raise ValueError('Device did not confirm installed bundle')
        report={'state':'installed','artifact':ARTIFACT,'bundle':BUNDLE,'tree_sha256':manifest['tree_sha256'],'executor':'reviewed_ios','model_role':'typed proposal only','gameplay':'not_verified'}
        output.write_text(json.dumps(report,indent=2));return report
    except Exception:
        output.write_text(json.dumps({'state':'uncertain','artifact':ARTIFACT,'message':'Inspect device result before retrying'}));raise

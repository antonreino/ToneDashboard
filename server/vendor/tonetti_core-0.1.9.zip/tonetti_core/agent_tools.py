"""Bounded, read-only tools for the Tonetti chat.

The language model cannot choose commands, hosts, paths or arguments.  A tool
result is evidence for one turn, never a claim that a maintenance task ran.
"""
import re
import subprocess
import sys
from pathlib import Path
from .storage import redact

SAFE_EXT={'.py','.js','.mjs','.css','.html','.md','.swift','.toml','.yml','.yaml','.sh'}
DENIED_PARTS={'.git','.env','.venv','data','backups','audits','node_modules','__pycache__','secrets','credentials'}


def _remote_read(remote_script,command,*,runner=subprocess.run):
    if not Path(remote_script).is_file():return 'Transporte de Proxmox no disponible.'
    try:
        result=runner([sys.executable,str(remote_script)],input=command,text=True,
                      capture_output=True,timeout=20,check=False)
    except (OSError,subprocess.TimeoutExpired):return 'Proxmox no respondió a la lectura.'
    if result.returncode:return 'Proxmox rechazó la lectura o no está accesible.'
    return result.stdout[:12000]


def proxmox_containers(remote_script,*,runner=subprocess.run):
    """Inventory from pct, without a command supplied by the model."""
    raw=_remote_read(remote_script,'pct list',runner=runner)
    if not raw or raw.startswith(('Transporte','Proxmox')):return raw or 'No hay resultado del inventario.'
    rows=[]
    for line in raw.splitlines()[1:]:
        parts=line.split()
        if len(parts)>=3 and re.fullmatch(r'\d{3,5}',parts[0]) and parts[1].lower() in ('running','stopped','paused') and re.fullmatch(r'[\w.-]{1,80}',parts[-1]):
            rows.append(f'CT{parts[0]} · {parts[-1]} · {parts[1].lower()}')
    return '\n'.join(rows[:80]) if rows else 'Proxmox respondió, pero no se pudo interpretar el inventario de contenedores.'


def proxmox_directories(remote_script,container_id=None,path='/',*,runner=subprocess.run):
    """List one allowlisted directory, on host or a numeric LXC; no traversal or shell."""
    if container_id is not None and not re.fullmatch(r'\d{3,5}',str(container_id)):
        return 'Identificador de contenedor no válido.'
    if path not in ('/','/app','/opt','/srv','/var/lib'):
        return 'Directorio fuera de la lista de lectura permitida.'
    command=f'ls -1 {path}' if container_id is None else f'pct exec {container_id} -- /bin/ls -1 {path}'
    raw=_remote_read(remote_script,command,runner=runner)
    if not raw or raw.startswith(('Transporte','Proxmox')):return raw or 'No hay listado disponible.'
    names=[line.strip() for line in raw.splitlines() if re.fullmatch(r'[\w .-]{1,100}',line.strip())]
    return 'Directorios y entradas de '+path+':\n'+'\n'.join(names[:100]) if names else 'La lectura no devolvió entradas válidas.'


def project_file(base,project,relative):
    """Bounded source read from one explicit repository; excludes private data."""
    if project not in ('ToneDashboard','tonetti','infra-maintenance'):raise ValueError('Proyecto no autorizado')
    if not relative or relative.startswith('/') or '\\' in relative:raise ValueError('Ruta no válida')
    parts=Path(relative).parts
    if any(part in ('..','.') or part in DENIED_PARTS or part.startswith('.') for part in parts):raise ValueError('Ruta privada o no válida')
    path=(Path(base)/project/relative)
    if path.is_symlink() or not path.is_file() or path.suffix not in SAFE_EXT or path.stat().st_size>80000:raise ValueError('Archivo no permitido')
    if not path.resolve().is_relative_to((Path(base)/project).resolve()):raise ValueError('Ruta fuera del proyecto')
    return redact(path.read_text(errors='replace')[:16000])


def _proxmox_memory(remote_script, *, runner=subprocess.run):
    """Read only RAM module fields; never return serials or the SSH key."""
    if not Path(remote_script).is_file():
        return 'No está disponible el transporte verificado de Proxmox.'
    try:
        result=runner([sys.executable,str(remote_script)],input='dmidecode -t 17',
                      text=True,capture_output=True,timeout=18,check=False)
    except (OSError,subprocess.TimeoutExpired):
        return 'Proxmox no respondió a la consulta de memoria. No puedo confirmar el modelo ahora.'
    if result.returncode:
        return 'La consulta de memoria en Proxmox falló. No puedo confirmar el modelo ahora.'
    modules=[]
    for block in result.stdout[:150000].split('Memory Device'):
        fields={}
        for key in ('Size','Manufacturer','Part Number','Speed','Configured Memory Speed','Type'):
            match=re.search(r'^\s*'+re.escape(key)+r':\s*(.{1,100})$',block,re.M)
            if match:fields[key]=match.group(1).strip()
        if fields.get('Size') and fields['Size'] not in ('No Module Installed','Not Installed'):
            modules.append(fields)
    if not modules:return 'Proxmox respondió, pero no publicó modelo de módulos RAM en dmidecode.'
    lines=[]
    for index,item in enumerate(modules[:16],1):
        lines.append(f"Módulo {index}: "+'; '.join(f'{key}: {item[key]}' for key in ('Size','Manufacturer','Part Number','Type','Speed','Configured Memory Speed') if key in item))
    return '\n'.join(lines)


def route(query, *, root, provider=None, memory_reader=None):
    """Return (answer, source) for a narrow live read, otherwise None."""
    q=query.casefold()
    root_path=Path(root).resolve()
    base=root_path.parents[2] if len(root_path.parents)>2 else root_path
    remote=base/'infra-maintenance'/'remote.py'
    if 'proxmox' in q and re.search(r'\b(contenedores|lxc|cts?)\b',q) and re.search(r'\b(lista|listar|cu[aá]les|inventario|muestra|ver|explora)\b',q):
        return 'Inventario leído ahora de Proxmox:\n'+proxmox_containers(remote),'proxmox:pct-list'
    if 'proxmox' in q and re.search(r'\b(directorios|carpetas|archivos|ra[ií]z)\b',q) and re.search(r'\b(localiza|lista|listar|muestra|explora|entra|hay|revisa|ver)\b',q):
        match=re.search(r'\b(?:ct|contenedor)\s*#?\s*(\d{3,5})\b',q)
        ident=match[1] if match else None
        path_match=re.search(r'(?<!\w)/(?:app|opt|srv|var/lib)\b',q)
        path=path_match.group(0) if path_match else '/'
        return 'Lectura de '+('CT'+ident if ident else 'host Proxmox')+':\n'+proxmox_directories(remote,ident,path),'proxmox:directories'
    if re.search(r'\b(lee|mu[eé]strame|abre|revisa|consulta)\b',q) and re.search(r'\b(c[oó]digo|archivo|fichero|fuente)\b',q):
        match=re.search(r'\b(ToneDashboard|tonetti|infra-maintenance)/([\w./-]+\.(?:py|js|mjs|css|html|md|swift|toml|yml|yaml|sh))\b',query)
        if match:
            try:source=project_file(base,match[1],match[2])
            except ValueError:return 'No puedo leer esa ruta: está fuera de los proyectos o contiene datos privados.','code:denied'
            return f'Archivo leído de {match[1]}/{match[2]} (hasta 16 000 caracteres):\n```\n{source}\n```','code:'+match[1]+'/'+match[2]
    if 'proxmox' in q and re.search(r'\b(ram|memoria)\b',q) and re.search(r'\b(modelo|marca|m[oó]dulos?|fabricante|referencia|part number)\b',q):
        if memory_reader is None:
            answer=_proxmox_memory(remote)
        else:answer=memory_reader()
        return 'Resultado de la consulta de solo lectura de RAM en Proxmox:\n'+answer,'proxmox:dmidecode-memory'
    if re.search(r'\b(tele|televisi[oó]n|tv)\b',q) and re.search(r'\b(logs?|registros?)\b',q) and re.search(r'\b(entra|accede|saca|s[aá]came|revisa|analiza|manda|guarda|deja)\b',q):
        return ('No tengo una conexión verificada a los registros de esa televisión desde el chat. '
                'No he leído ni exportado ningún log. Para hacerlo necesito una herramienta de lectura '
                'de la TV configurada y comprobar primero el acceso; no voy a inventar un análisis.'),'capability:tv-logs-unavailable'
    if re.search(r'\b(ejecuta|lanza|corre|inicia)\b',q) and re.search(r'\b(tarea|mantenimiento|revisi[oó]n)\b',q):
        return ('No he ejecutado ninguna tarea desde este mensaje. En Tonetti abre «Preparar una tarea de mantenimiento», '
                'elige la tarea y revisa el plan antes de confirmarla. El panel mostrará el resultado real; '
                'la respuesta del modelo no es una ejecución.'),'capability:task-plan'
    return None

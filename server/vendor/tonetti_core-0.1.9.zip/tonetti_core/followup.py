"""Conservative retrieval scope for short anaphoric follow-ups.

Only completed user turns in the open conversation can supply an antecedent.
This enriches retrieval, never an execution request or a stored user statement.
"""
import re
import unicodedata

def _plain(text):
    return ''.join(c for c in unicodedata.normalize('NFKD',text.casefold()) if not unicodedata.combining(c))

_SUBJECT = re.compile(r'\b(?:ps5|playstation|play|proxmox|emby|anime|amule|nginx|iphone|ios|mac|ollama|tonetti|jarvis|organizer|organizador|sqlite|dns|adguard|nanodns|dashboard|git(?:hub)?|immich|dispatcharr)\b')
_REFERENCE = re.compile(r'\b(?:eso|ese|esa|esos|esas|esto|estos|estas|entonces|ahora|anterior|mismo|misma|continua|sigue)\b')

def is_followup(text):
    plain=_plain(text)
    return len(text)<=240 and bool(_REFERENCE.search(plain)) and not _SUBJECT.search(plain)

def retrieval_query(query,history):
    if not is_followup(query):return query
    # Stop at the nearest substantive user turn; do not combine unrelated threads,
    # model statements, attachments or arbitrarily distant recalled messages.
    for role,content in reversed(history):
        if role!='user' or content.strip()==query.strip():continue
        if is_followup(content):continue
        if len(content)>1200:return query  # A large pasted document is ambiguous.
        return query+'\nAntecedente del usuario en este hilo: '+content
    return query

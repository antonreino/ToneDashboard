"""Append-only conversation storage, private backups and searchable memory."""
from contextlib import contextmanager
from pathlib import Path
import os
import re
import sqlite3
import unicodedata

STOP = set('a al algo como con cual cuales cuando de del donde el ella en es esta este estos ha hay la las le lo los me mi mis no nos o para por que qué se si sin sobre su sus te tiene todo tu un una unos y yo recuerda segun según favor dime puedes'.split())
ALIASES = {'play': 'ps5 consola jailbreak', 'playstation': 'ps5 consola', 'organizador': 'organizer emby detect_spanish_episode', 'organizer':'emby detect_spanish_episode absolute telenovela', 'nginx': 'npm proxy certbot', 'tele': 'lg television', 'tonetti': 'asistente memoria', 'jarvis': 'tonetti asistente', 'proxmox': 'ct lxc contenedor host', 'tareas': 'automatizaciones programadas', 'codigo': 'python javascript fuente', 'dedico':'profesion programador perfil', 'dedicas':'profesion programador perfil', 'profesion':'programador empleo perfil'}
SECRET = re.compile(r'(?im)^.*(?:password|passwd|contrase[ñn]a|secret|api[_ -]?key|access[_ -]?token|token|clave|credential|authorization|passphrase)\s*[:=].*$|-----BEGIN[\s\S]*?-----END[^\n]*|\b\d{5,}:[\w-]{15,}\b|\bBearer\s+\S+')

def redact(text):
    return SECRET.sub('[credencial omitida]', str(text))

def terms(text,limit=40):
    text = ''.join(c for c in unicodedata.normalize('NFKD', text.lower()) if not unicodedata.combining(c))
    return [t for t in re.findall(r'[a-z0-9_]{2,40}', text) if t not in STOP][:limit]

@contextmanager
def connect(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True,mode=0o700);os.chmod(root,0o700)
    db=sqlite3.connect(root/'chat.sqlite3', timeout=15)
    try:
        db.execute('PRAGMA busy_timeout=15000')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,role TEXT,content TEXT,state TEXT,at TEXT);
        CREATE VIRTUAL TABLE IF NOT EXISTS recall USING fts5(content,source UNINDEXED,reference UNINDEXED,at UNINDEXED,tokenize='unicode61 remove_diacritics 2');
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS response_sources(message_id INTEGER PRIMARY KEY,sources TEXT);
        CREATE TABLE IF NOT EXISTS feedback(id INTEGER PRIMARY KEY,message_id INTEGER,correction TEXT,at TEXT);
        ''')
        os.chmod(root/'chat.sqlite3',0o600)
        with db:yield db
    finally:db.close()

def index_message(db, ident, content, at):
    # Only the user's statements become recall. Model answers are not evidence.
    db.execute("DELETE FROM recall WHERE source='conversation' AND reference=?", (str(ident),))
    db.execute('INSERT INTO recall(content,source,reference,at) VALUES(?,?,?,?)', (redact(content),'conversation',str(ident),at))

def backfill(db):
    # Migration is repeatable and does not alter existing conversations.
    if db.execute("SELECT value FROM settings WHERE key='recall_migrated'").fetchone():return
    for ident,content,at in db.execute("SELECT id,content,at FROM messages WHERE role='user' AND state='done'").fetchall():
        index_message(db,ident,content,at)
    db.execute("INSERT INTO settings VALUES('recall_migrated','1')")

def search(db,query,limit=8):
    words=terms(query)
    for word in list(words):words.extend(terms(ALIASES.get(word,'')))
    words=list(dict.fromkeys(words))[:45]
    if not words:return []
    expression=' OR '.join('"'+w+'"' for w in words)
    rows=[]
    for source in ('conversation','document','code'):
        rows.extend(db.execute("SELECT content,source,reference,at,bm25(recall) FROM recall WHERE recall MATCH ? AND source=? ORDER BY CASE WHEN content LIKE '# Función real:%' THEN 0 ELSE 1 END,bm25(recall),rowid DESC LIMIT 32",(expression,source)).fetchall())
    conversation=[r for r in rows if r[1]=='conversation']
    if not any(w in words for w in ('pregunte','pedi','hablamos','conversacion','dije')):
        conversation=[r for r in conversation if '?' not in r[0]]
    base=set(terms(query))
    conversation=[r for r in conversation if len(base.intersection(terms(r[0],None)))>=min(2,len(base))]
    conversation.sort(key=lambda r:r[3] or '',reverse=True)
    documents=[r for r in rows if r[1]=='document']
    code=[r for r in rows if r[1]=='code']
    coding=any(w in words for w in ('codigo','script','scripts','parche','parser','funcion','python','javascript','modifica','implementar','fuente','csv','workflow','archivo','pruebas','test','corregir','arreglar'))
    selected=conversation[:3]+documents[:(4 if coding else limit-3)]
    if coding:selected+=code[:max(0,limit-len(selected))]
    for row in conversation+documents:
        if len(selected)>=limit:break
        if row not in selected:selected.append(row)
    return [dict(zip(('content','source','reference','at','rank'),r)) for r in selected[:limit]]


def snippet(text,query,limit=2200):
    """Keep the matching passage even when a remembered fact is near the end."""
    if len(text)<=limit:return text
    normalized=''.join(c for c in unicodedata.normalize('NFKD',text.casefold()) if not unicodedata.combining(c))
    anchor=0
    for word in sorted(set(terms(query)),key=len,reverse=True):
        match=re.search(r'\b'+re.escape(word)+r'\b',normalized)
        if match:
            anchor=max(0,match.start()-300);break
    return ('[…]' if anchor else '')+text[anchor:anchor+limit]

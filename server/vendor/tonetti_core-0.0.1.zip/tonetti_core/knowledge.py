"""Explicit, bounded, local source indexing. No network, shell or arbitrary paths."""
from datetime import datetime,timezone
import ast
import hashlib
import re
from pathlib import Path
from .storage import connect,redact

EXTENSIONS={'.py','.js','.mjs','.md','.css','.html','.toml','.swift','.yaml','.yml','.sh'}
EXCLUDED={'data','.git','.venv','node_modules','legacy','audits','tests','__pycache__','static','native'}

def chunks(text, size=28, overlap=5):
    lines=text.splitlines()
    for start in range(0,len(lines),size-overlap):
        yield start+1,'\n'.join(lines[start:start+size])[:5000]

def index_files(root, project, paths):
    project=Path(project).resolve();count=0
    with connect(root) as db:
        for candidate in paths:
            path=Path(candidate)
            if path.is_symlink():continue
            path=path.resolve()
            if not path.is_relative_to(project) or not path.is_file() or path.stat().st_size>180000:continue
            relative=path.relative_to(project)
            if path.suffix not in EXTENSIONS or any(p in EXCLUDED or (p.startswith('.') and not (i==0 and p=='.github')) for i,p in enumerate(relative.parts)):continue
            raw=path.read_text(errors='replace')
            text=redact(raw)
            reference=project.name+'/'+relative.as_posix()
            digest=hashlib.sha256(('index-v3:'+text).encode()).hexdigest();key='file:'+reference
            old=db.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
            if old and old[0]==digest:continue
            db.execute("DELETE FROM recall WHERE source='code' AND reference LIKE ?",(reference+':%',))
            sections=list(chunks(text))
            if path.suffix=='.py':
                try:
                    tree=ast.parse(raw);lines=raw.splitlines()
                    for node in ast.walk(tree):
                        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                            start=node.lineno-1;end=min(node.end_lineno,start+110)
                            part=redact('\n'.join(lines[start:end]))[:6500]
                            sections.append((node.lineno,'# Función real: '+node.name+'\n'+part))
                except SyntaxError:pass
            for line,part in sections:
                db.execute('INSERT INTO recall(content,source,reference,at) VALUES(?,?,?,?)',(part,'code',reference+':'+str(line),datetime.now(timezone.utc).isoformat()))
            db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,digest));count+=1
    return count

def import_document(root,path,reference):
    path=Path(path)
    if not path.exists():return 0
    text=redact(path.read_text())
    with connect(root) as db:
        digest=hashlib.sha256(text.encode()).hexdigest();key='document:'+reference
        previous=db.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        if previous and previous[0]==digest:return len(text)
        db.execute("DELETE FROM recall WHERE source='document' AND reference LIKE ?",(reference+':%',))
        # Never combine unrelated runbooks or headings in one retrieval chunk.
        lines=text.splitlines();boundaries=[i for i,line in enumerate(lines) if re.match(r'^#{1,3} ',line)]
        if not boundaries or boundaries[0]!=0:boundaries.insert(0,0)
        boundaries.append(len(lines))
        for start,end in zip(boundaries,boundaries[1:]):
            section='\n'.join(lines[start:end])
            for line,part in chunks(section,24,3):
                db.execute('INSERT INTO recall(content,source,reference,at) VALUES(?,?,?,?)',(part,'document',reference+':'+str(start+line),datetime.now(timezone.utc).isoformat()))
        db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,digest))
    return len(text)

"""Project names and aliases are facts, not a model guessing filesystem paths."""
import json
from pathlib import Path

def projects(root,query):
    path=Path(root)/'projects.json'
    if not path.is_file() or path.stat().st_size>32000:return []
    try:
        rows=json.loads(path.read_text()).get('projects',[])
        if not isinstance(rows,list):return []
        q=query.casefold();selected=[]
        for row in rows[:30]:
            if not isinstance(row,dict):continue
            aliases=row.get('aliases',[])
            if not isinstance(aliases,list):continue
            if any(isinstance(a,str) and a.casefold() in q for a in aliases):
                selected.append({key:str(row.get(key,''))[:1800] for key in ('name','path','url','description')})
        return selected
    except (ValueError,OSError,AttributeError):return []

def describe(rows):
    return '\n\n'.join(row['name']+'\nRuta: '+row['path']+'\nRepositorio: '+row['url']+'\n'+row['description'] for row in rows)

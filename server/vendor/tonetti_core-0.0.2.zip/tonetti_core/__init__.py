"""Tonetti: persistent local context, without autonomous execution."""
__version__ = '0.0.2'
